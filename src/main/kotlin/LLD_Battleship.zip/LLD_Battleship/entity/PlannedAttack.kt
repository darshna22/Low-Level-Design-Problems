package LLD_Battleship.entity

data class PlannedAttack(val attacker: Player, val target: Player, val position: Coordinate)