package LLD_Battleship.entity

data class Coordinate(val x: Int, val y: Int)
