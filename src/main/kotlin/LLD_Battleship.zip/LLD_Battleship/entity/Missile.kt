package LLD_Battleship.entity

data class Missile(val name: String = "", val missileId: Int = 0, val attackPosition: Coordinate)
